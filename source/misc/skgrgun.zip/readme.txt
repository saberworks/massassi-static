Greedo Gun Massassi Version

1998 Kevin 'Red' Enser
-------------------------------------------------------------------

Title		: Greedo Gun
Filename	: skgrgun.zip
Version  	: 1.0
Date		: 08/12/98
Author		: Kevin 'Red' Enser
Email		: theensers@earthlink.net
URL		: http://www.jedinights.com/skinners
Credits	        : moi
Build time	: A Few Days -- but it wasn't easy!
Thanks To       : Even C for his Gun Tutorial, Pot-Head for his info, LA for the base,
                  and DarkJedi.Com for their editors. Thanks guys!

Notes
-----

Although I did read what Even C and Pot-Head wrote I decided to use my own way :-)
This is how I did it:

	1) Made My Meshes via JED (I actually tricked JED into merging 2 non adjoined
           Sectors from io.3do (hand and weapon)
	2) Made a Template for my mesh and the bryar pistol so I could see their wireframes lined up
	3) Using Ghosts I figured out how off center my model was and wrote down the Delta between
	   their points and mine.
	4) Using wordpad I manually + or - the distance I was off in each coord.

This would've been 500% easier if someone made a 3do converter that'd offset your model for you :-)

Construction
------------

Base                    : LA Models
Editor(s) used          : JED v8.1, Mat Master, ConMan, JKGOB, and Wordpad
Known Bugs              : None


Description of the Modification
-------------------------------
Greedo's Gun's Mesh insted of Kyle's Bryar. I figured not everyone in the
Star Wars Universe has a custom Bryar :-) So, those who are making Single
Player levels without Kyle as the lead actor can use this mesh. Check
the Copyright for more info on this.

I *believe* the technical name for this gun is the "Relby-K23 Blaster Pistol"

Copyright/Permissions
---------------------

Authors MAY use this MOD as a base to build additional levels/MODs.
 
THIS MOD IS NOT MADE, DISTRIBUTED, OR SUPPORTED BY LUCASARTS ENTERTAINMENT 
COMPANY.  ELEMENTS TM & (C) LUCASARTS ENTERTAINMENT COMPANY.

Authors MAY include these UNEDITED meshes in their projects as long as they:

	1) Include this readme
	2) Include Greedo Gun Mesh made by Skinners (http://www.jedinights.com/skinners)

Availability
------------
The Massassi Temple
http://massassi.jedinights.com/

-Kevin 'Red' Enser Project Director
theensers@earthlink.net
UIN: 2029978