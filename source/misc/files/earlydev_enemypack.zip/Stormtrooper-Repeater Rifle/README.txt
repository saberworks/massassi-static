==JEDI KNIGHT ADDON ENEMY PACK====================================
Title                   : 
File Name               : earlydev_enemypack.ZIP
File Size               : 323 kb
Author(s)               : KnightCop, Shimstock
Date of Release         : 1/2/2024

Email Address           : wesley.schemmer@gmail.com
Misc. Author Info       : 

Description             : 	Enemy 4-pack, using unreleased early JK development weapons!

				The Tusken prod and stormtrooper rifle repeater, as seen in early JK advertisements, were ultimately scrapped before the final release. However, related files were left behind 
				in both JK and MotS original game assets. The weapons and their functions were recreated as faithfully as possible to the available source material.
				The AI for repeater rifle enemies gives them a long-range preference.

				The following enemies use these weapons: 
					1) Brown/Black Tusken with Tusken Prod
					2) Imperial Commando with Repeater Rifle
					3) Stormtrooper with Repeater Rifle
					
			  In addition, a fourth early development enemy is included: 8t88's Beast/Dog Grendel. The enemy, as seen in cutscenes, was intended for use in JK. Unused files were left in MotS assets.
				It was discarded possibly because it needed the "leap" ai instinct, which was not ready until MotS. I suspect this because the key animations correlate with the Vornskyr leap attack. 
				Interestingly, the upper and lower jaw textures were renamed and reused for the Vornskyr. Another iteration of this enemy was found in "The Continuing Adventures of Mara Jade" 
				in which the model was used as a _flyactor; whereas accurately the enemy was designed to primarily walk. I would like to emphasize the enemy is a boss and is designed to be a challenge.
				While it functions in both JK and MotS, the leaping instinct in MotS gives it the more authentic experience. Lastly, original and upscaled sounds for the dog are included, for your
				preference.
 				

Additional Credits to   : SMLiberator--shared 8t88's beast fixed 3do model and some keys that had corrected scaling. Last but not least, the ever helpful and fantastic JK community.

Beta Testers            : KnightCop

Development machine     : eg. P133 with 16MB RAM, Matrox Mystique
Machine(s) tested on    : Windows 10, x64, AMD A8-7410 APU with AMD Radeon R5 Graphics, 8GB RAM; 
				Complete POS, somehow barely runs JK
================================================================

* Play Information *

Episode name            : N/A
Level name(s)           : N/A
JK version required     : Jedi Knight Basic / Mysteries of the Sith Addon
Difficulty Settings     : N/A

New COGs                : Yes
New Textures:
  New MATs              : No
  New BMs               : No
New Objects:
  New 3DOs              : Yes
  New KEYs              : Yes
  New PUPs              : Yes
  New AIs               : Yes
New SFTs                : No
New WAVs                : Yes (Tusken prod firing, mixed mainly by KnightCop, based on sound from video advertisement)
New CMPs                : No
New PARs                : No
New SPRs                : No
New Briefings           : No
New Cutscenes           : No

* Construction *

Base                    : Original untextured tusken prod models, original repeater rifle model, original grave tusken + stormtrooper + imperial commando models
Editor(s) used          : Notepad-cogscript; Pjedi-key; JED/ZED-3do
Known Bugs              : None

================================================================

* I admit that * 
(as required by the LEC Licence Agreement about Addon Levels)

1. My Addon works only with the retail version of the
   Software, and does not work with any demo or OEM versions
   of the Software.  
2. My Addon does not modify any COM, EXE, DLL or other executable files.
3. My Addon does not contain any illegal, scandalous, 
   illicit, defamatory, libelous, or objectionable material
   (as may be determined by LEC in its sole discretion), or
   any material that infringes any trademarks, copyrights,
   protected works, publicity, proprietary, or other rights
   of any third party or of LEC.  
4. My Addon does not include any LEC sound effects or music files or 
   portions thereof.
5. My Addon identifies in every description file, on-
   line description, read-me, and in comments in the New
   Level code: (a) the name, address, and e-mail address of
   the level's creators, and (b) the following disclaimer:
   "THIS LEVEL IS NOT MADE, DISTRIBUTED, OR SUPPORTED BY
   LUCASARTS ENTERTAINMENT COMPANY.  ELEMENTS TM & (C) 
   LUCASARTS ENTERTAINMENT COMPANY."
6. My Addon may not be sold, bartered, or distributed with
   any other product for which any charge is made (other than
   incidental charges for time spent on-line), but rather
   must be distributed free of charge. 
7. By distributing or permitting the distribution of any New
   Addons, all creators or owners of any trademark, 
   copyright, or other right, title or interest therein grant
   to LEC an irrevocable, perpetual, royalty-free, sub-
   licensable right to distribute the New Addon by any means
   (whether now known or hereafter invented), and to create
   and distribute by any means (whether now known or here-
   after invented) derivative works thereof, and to charge
   for the distribution of such New Addon or such derivative
   work, with no obligation to account to any creators or
   owners of the New Addon in any manner.

* Copyright / Permissions *

Authors (MAY) use this Mod as a base to build additional levels/mods.  
THIS MOD IS NOT MADE, DISTRIBUTED, OR SUPPORTED BY LUCASARTS ENTERTAINMENT 
COMPANY.  ELEMENTS TM & (C) LUCASARTS ENTERTAINMENT COMPANY.

You MAY distribute this Mod, provided you include this file, with
no modifications.  You may distribute this file in any electronic
format (BBS, Diskette, CD, etc) as long as you include this file 
intact, with NO charge (other than incidental charges for time spent on-line). 
