==JEDI KNIGHT ADDON MISSION====================================
Title                   : The Massassi Level Pack #2
File Name               : mlp2.zip
File Size               : 3.58Megs
Author(s)               : Nebula     - Deep
                          Slug       - Vanilla
                          darkjedi86 - Minas Fragith
                          Jepman     - Fallen Once
                          GH_wasica  - Murky Fate
                          SIM_BLIMKE - Tropical Island

Date of Release         : 03/00

Email Addresses         : Nebula     - solarwind@mediaone.net
                          Slug       - slug@massassi.net
                          darkjedi86 - darkjedi86@xoommail.com
                          Jepman     - bakalord@hotmail.com
                          GH_wasica  - wasica@thegameguru.com
                          SIM_BLIMKE - iamthewally@hotmail.com

Misc. Author Info       : A bunch of incredibly handsome, talented guys.

Description             : The Massassi Level Pack #2, comprised of some of the community's
                          greatest talent.

Additional Credits to   : Speak, Rage, Maheda, RobX, NorthChaos, darkjedi86, and Slug - Judges
			  Slug - Compilation
                          Code Alliance - The sweet candy center of the community.

Beta Testers            : Speak, Rage, Maheda, RobX, NorthChaos, darkjedi86, and Slug.

Development machine     : Various
Machine(s) tested on    : Various
================================================================

* Play Information *

Episode name            : Massassi Level Pack 2
Level name(s)           : Deep, Vanilla, Minas Fragith, Murky Fate, Tropical Island, Fallen Once
JK version required     : Jedi Knight Basic
Difficulty Settings     : Not implemented

New COGs                : Yes
New Textures:
  New MATs              : Yes
  New BMs               : No
New Objects:
  New 3DOs              : Yes
  New KEYs              : Yes
  New PUPs              : Yes
  New AIs               : Yes
New SFTs                : No
New WAVs                : Yes
New CMPs                : No
New PARs                : No
New SPRs                : No
New Briefings           : Yes
New Cutscenes           : No

* Construction *

Base                    : New levels from scratch
Editor(s) used          : JED v.**
Known Bugs              : None - You think I'd let bugs get in this pack? What're you, simple?

================================================================

* I admit that * 
(as required by the LEC Licence Agreement about Addon Levels)

1. My Level works only with the retail version of the
   Software, and does not work with any demo or OEM versions
   of the Software.  
2. My Level does not modify any COM, EXE, DLL or other executable files.
3. My Level does not contain any illegal, scandalous, 
   illicit, defamatory, libelous, or objectionable material
   (as may be determined by LEC in its sole discretion), or
   any material that infringes any trademarks, copyrights,
   protected works, publicity, proprietary, or other rights
   of any third party or of LEC.  
4. My Level does not include any LEC sound effects or music files or 
   portions thereof.
5. My Level identifies in every description file, on-
   line description, read-me, and in comments in the New
   Level code: (a) the name, address, and e-mail address of
   the level's creators, and (b) the following disclaimer:
   "THIS LEVEL IS NOT MADE, DISTRIBUTED, OR SUPPORTED BY
   LUCASARTS ENTERTAINMENT COMPANY.  ELEMENTS TM & (C) 
   LUCASARTS ENTERTAINMENT COMPANY."
6. My Level may not be sold, bartered, or distributed with
   any other product for which any charge is made (other than
   incidental charges for time spent on-line), but rather
   must be distributed free of charge. 
7. By distributing or permitting the distribution of any New
   Levels, all creators or owners of any trademark, 
   copyright, or other right, title or interest therein grant
   to LEC an irrevocable, perpetual, royalty-free, sub-
   licensable right to distribute the New Level by any means
   (whether now known or hereafter invented), and to create
   and distribute by any means (whether now known or here-
   after invented) derivative works thereof, and to charge
   for the distribution of such New Level or such derivative
   work, with no obligation to account to any creators or
   owners of the New Level in any manner.

* Copyright / Permissions *

Authors may NOT use this level as a base to build additional levels.  
THIS LEVEL IS NOT MADE, DISTRIBUTED, OR SUPPORTED BY LUCASARTS ENTERTAINMENT 
COMPANY.  ELEMENTS TM & (C) LUCASARTS ENTERTAINMENT COMPANY.

You MAY distribute this level, provided you include this file, with
no modifications.  You may distribute this file in any electronic
format (BBS, Diskette, CD, etc) as long as you include this file 
intact, with NO charge (other than incidental charges for time spent on-line).