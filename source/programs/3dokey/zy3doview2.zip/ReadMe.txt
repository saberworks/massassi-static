3do View (public release 2, July 30, 2003)
	by Zymotico (zymotica@hotmail.com)
------------------------------------------
This program will load and display LucasArts' Jedi Knight 3dos.

I wrote this program as an exercise in learning OpenGL and basic 3d model loading.
This program is far from commercial quality, and is for personal amusement.
This program is FREEWARE and has no warranty whatsoever.

Config.txt is where you can set the background color
In the directory systemtex is where you will find the texture for shiny environment mapping.
Change as you desire.  Checker.tga is my version of dflt.mat in the case a mat file is not found.  After 3doView is executed, in the same directory as the 3do, a "ModelStats.txt" file will be generated.

n1.3do is included as a sample 3do file.


Control keys:

W,S	= zoom camera (pan forward/backward)
A,D	= Rotate 3do
R,F	= Rotate 3do
T,G	= Rotate 3do
I,K	= Pan camera
J,L	= Pan camera

F1	= Toggle fast/not as fast panning movement sizes
F5	= Wire, Flat, Smooth toggle
F6	= Textured Model toggle
F7	= OpenGL lighting toggle
F8	= Shiny toggle
F9	= Load New 3do file
F12	= Take Screenshot (TGA files will be saved in same directory as the current 3do)

space	= Reset View angles
h	= Toggles the Showing of FPS, Keyboard Help Screen, and No Text display
esc	= exit program


Known Issues:

If the first mesh of the 3do is transparent, the rest of the 3do may render funny.
Feeding the viewer non 3dos may cause it to crash.


Developing Machine Specs:

	PII 400MHz
	256 Mb system memory
	Geforce2 GTS 32Mb DDR RAM

	Typical frame rates (with typical JK 3dos, non wire mode) = 400+ fps
