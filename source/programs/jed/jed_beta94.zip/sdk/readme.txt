jed_plugins.pas		is an interface unit for Delphi 2.0/
			3.0 (probably works with 4.0, but not 
			tested).
jed_plugins.h		is a header file for C/C++. Tested 
			with C++ Builder.

sample.zip 		is a simple Delphi 2.0/3.0 test plug-in.
formsample.zip		demonstrates how to use forms in your
			plugins.

Create a new DLL project, add the appropriate unit to it and
you're ready to make your new plug-in. Declare a function
JEDPluginLoadStdCall, exported by name. make sure it uses
standard calling convention ("stdcall") This is the function 
JED calls when it loads/activates your plugin. The one 
parameter of this function is IJED interface object which 
you can use to communicate with JED.


Hopefully soon I'll compile a more detailed description, but
I hope that's enough to get your started.

Alex.
