OH NO!!!!!!
ANOTHER DAMM UNIT VECTOR CALCULATOR FOR JED.

Ok, sure it's another one.
But at least this one is done in Delphi 3 and not damm Visual Basic.
Damm support dll's.
 
Plus i've tried to make it as small, helpful and colorful as I could.
Damm anyone who says aqua, lime and black don't mix.

Thanks guys.
I visit Jedi Nights usually every day and generally leave when my damm
ISP throws me off.

Craig Urquhart (Gomez)
cu@suburbia.com.au