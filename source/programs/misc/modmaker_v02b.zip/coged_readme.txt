CogEd v0.2b - 1/11/99

Ok, this is just a BRIEF descriptionn of some of CogEd's features.
1) CogExplorer: Load up a cog, select CogExplorer from the "CogRef" combo box, then choose a cog
		from the box to the right of that.  In the tree view will be a listing of all of the declared
		symbols in the cog, along with any // comments.  You can rename a symbol and change its 
		default value by editing its label.  You can also delete an unused symbol or comment line by
		selecting it and pressing the delete key.  If you double-click on an entry it will reposition
		the cog to that line.  
2) Add Symbol: Select the symbol type, enter in a name.  Put in default value, choose whether it
		is local or not and specify a linkid.  Hit the "Add" button and the symbol will be generated
		right above the "end" line for the symbols section.  Only the type & name need to be specified.
3) Tree Menu: Use this to either expand or collapse CogRef or CogExplorer.  You can also use it
		to search through all of the nodes for the selected view.
4) Open Template: This can be used if you have a base cog that you customize by changing some 
		parameters or values.  The format for a .cgt file is as follows:
		3
		Default Value,Variable,Description
		BLARG!,message,Message to Print
		1,played,Number of times the message will print when the sector is entered
		end
		the "3" is the number of column headers
		the next line specifies the header text
		each line after that is a variable that can be replaced
		the last line before the cog is "end"  Note that you can not have blank lines.
		The 2nd parameter, either "message" or "played" in this case, is the name of the variable
		to replace.  In the cog where you want them to be replace with the value the user enters, put
		<% %> around the variable.
		example: if(played >= <%played%>) return;
		CogED will go through and replace <%played%> with 1 if the user doesn't change the value.
5) CogRef: This is basically an in-line version of dr0id's awesome CogRef program.  Basically it
		functions the same.  You can use the Tree commands to manipulate it.  Single-clicking on it
		will display a description of the function in the long text box at the bottom.  Double-
		clicking on a function will insert it at the current cursor location in the selected cog.
6) CogHelp: Typing in a cog function immediately followed by a open parenthesis will activate
		CogHelp.  Basically what will happen is the description of the function will show in the text
		box at the bottom of CogED and a label containing the function and its parameters will show 
		up in a label at the bottom of the cog.
7) CogQuick: The first implementation of CogQuick is in the symbols section.  If you are between
		the "symbols" and "end" lines, and type in "message" followed by a space, a list box 
		containing all available messages will pop up.  You can continue typing until the message you 
		want is selected, or just double click on it in the list box.  Note that this has not been 
		thoroughly tested and might result in a program crash, so save your work before trying this 
		out.
		
		
Ok, that's about all the features I can think of for now.  If you find any bugs PLEASE post them
on the Mod Maker message board at http://www.cues.com/modmaker  I can not stress this enough, I
can't make the program bug-free unless you let me know of the bugs you find.  Also, if you have
suggestions/comments/ideas for the program, post them on the board too.  It's nice to know that
all the time I've spent on this made someone's life easier.

Ok, for the thanks: dr0id for making CogRef, dylan & armage for helping with Mod Maker.  I'd also
like to thank my beta testers RBF, Magi, Palithius, Farrax and Cpt. Ramen for finding bugs and 
giving me feedback.


Erick Nelson
aka Dark Knight
ign@mediacity.com
http://www.cues.com/modmaker


CogED History (well since I started recording changes anyways)

Version 0.2.0b - 1/4/99 to 1/11/99
	bugfix: CogHelp would not work if it was preceeded by a tab
	Added CogExplorer
		Lists all symbols and comments in cog
		Allows you to rename symbols and change their default value.  Will rename all occurances of
			that symbol in the cog
		Allows you to use // comments as bookmarks in your cog.  You can also delete & rename these
			from within CogExplorer
		Allows you to delete symbols if they are not present in the code section of the cog
	Added checking for no symbol type or name for the "Add Symbol" command
	Fixed miscellaneous bugs resulting from implementation of CogExplorer
	bugfix: When you double clicked on a +- node in CogRef or CogExplorer, the program would crash
	Added a refresh(F5) command to refresh CogExplorer.
	Added a Save All command	
	Modified the CogFunction menu items to work with both CogRef and CogExplorer.  The menu name
		was also changed to Tree.  
	Added a font selection dialog box.  Default settings are Courier New, 8pt.  When box is loaded
		it contains your current font settings.  They are immediately saved & all cogs updated when
		you choose a different font.
	Added the ability to print cogs.  They will be printed with the current font settings.
	Added the "about" form
	Added the "message " drop down box.