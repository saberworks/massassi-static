Thanks for downloading Class Creator!  A few things before you get started creating new 
MotS Classes though ;)

First run version.exe, a cool little program whipped up by Frank Krueger of CA.

If the only red lights are for msvbvm50.dll and comcat.dll then you don't need to 
download anything else, fire up ClassCreator.exe!  However, if more than those 2 are red then 
you need to download classcreator_DLLs.zip  This will (should) be the only time you will need
to download those files.

Use the tutorial in the help file to give you a brief overview of Class Creator.  You can also
open up test.ccf to see how the custom weap.dat deal works.

You will notice two files are included, ccf.reg and ccfile.reg.  You can change the path inside
of them and patch them into the registry for you to be able to open .ccf files from Explorer.
What you need to do is open up ccf.reg and CCFile.reg
Inside each change "C:\Program Files\DevStudio\Class Creator" to the directory where you
installed Class Creator.  Then double click on each file to patch it into the registry
and associate em =)

If you have any questions or comments, mail me.  If you have a bug, goto 
http://www.cues.com/creator and goto the bug page.  I'm going to be outta town till the 30th,
so don't expect email replies anytime soon.

Erick
ign@mediacity.com