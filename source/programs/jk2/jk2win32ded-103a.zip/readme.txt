Star Wars Jedi Knight II dedicated server for Win32.
Version 1.03a

With much gratitude to James Drews and sorting out the problems.

This archive file contains:
  readme.txt    : The file your reading now
  jk2ded.exe    : Jedi Knight 2 win32 executable
  Disclaimer-Jedi Outcast Dedicated Server.doc : What you can't do

Updated Binary patch 1.03a:
-fix com_error on very large packet fragments

previous releases:
1.03- compatible with pc point release 1.03 ( you must install the 1.03 patch first! )
c)-empty connect msg exploit crash
  -dedicated console simple tab complete and one-line history
b)-random server crashes
  -ERROR: opStack corrupted in compiled code

Install instructions:

-Copy jk2ded.exe into the installation folder of JK2:JO
e.g. "C:\Program Files\LucasArts\Star Wars JK II Jedi Outcast\GameData"

Running the dedicated server:

-browse to the game directory
-double click the executable to launch, and then type:
exec server.cfg
(or you may wish to create a shortcut and add +exec server.cfg to the command line.)

This example used the sample file called server.cfg in the "base" directory.
You should edit this file and add your own settings.

By default, the server will run in "internet" play mode and advertise its presense to 
the master server. If you wish to have a LAN play only server, change your server 
config to set dedicated 1, or change the command line options to:
    +set dedicated 1 + exec server.cfg


Notes:
-The game will look in the base directory for pak and config files.


� 2002 LucasArts Entertainment Company LLC, � 2002 Lucasfilm Ltd 
& � or � as indicated. All rights reserved. Used Under Authorization. 
LucasArts and the LucasArts logo are registered trademarks of Lucasfilm Ltd. 
Activision is a registered trademark of Activision, Inc. � 2002 Activision, Inc. 
This product contains software technology licensed from Id Software, Inc. Id Technology � 1999-2002 Id Software, Inc. 
All other trademarks and trade names are the properties of their respective owners.