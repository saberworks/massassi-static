                      ----------------------__  -------
                       \   / \  ~~~\| \  |~~~\ \ \   /
                        | |   | |__,   | |    | | | |
                        | |   | ___|   | |    | | | |
                        | |   | |  `   | |    | | | |
                        | |  /  |__/| /  |___/ / /   \
                     /\_| | -----------------~~ -------
                   /______/
     ------- ,------  ------------ __-----__ ------------------------ TM
      \   / / /  \   \ \   / \   / /  /---\ |  \   / \   / |/~~| |~~\|
       | |/ /     |   \ | |   | | |  |      '   | |___| |      | |
       |   \      | |\  \ |   | | |  |   \~~~/  |  ___  |      | |
       | |\  \    | | \   |   | | |  |    | |   | |   | |      | |
      /   \ \  \ /   \ \  |  /   \ \  \---  |  /   \ /   \    /   \
     ------- '--------- \ | ------- ~~----~~  -------------  -------
                         `'
                          MAT MASTER v. 2.00 beta

              programmed by Peter Klassen of the Code Alliance

           report any bugs/suggestions under thehutt@darkjedi.com

                The Code Alliance page: http://www.darkjedi.com

Requirements: Windows 9x, 256c/HiColor mode.
I tested it on 800x600, it could be that the program won't look right
on LargeFonts. The colors of the Color Palette will be dithered on 256
color modes.
JED v.0.93+ is supported.


How To Install:
---------------

With JED v.0.93+:
-----------------

Under the \Plugins subdirectory of your JED directory, create a folder for MatMaster. 
Call it a name you'd like to appear in the Plugins menu of JED. Best would be
"MatMaster". :-)

Unpack the contents of the ZIP file into this directory.
You may want to create a Startmenu or Desktop shortcut with Matmaster.exe.

In JED, a submenu "MatMaster" will appear in the Plugins menu. You can run MatMaster JED
(enhanced to use JED plugin interface) or MatMaster Standard (the normal MatMaster).

Without JED:
------------
Create a directory you want to install MatMaster into. Extract the contents of the
ZIP file into your directory. You may want to create a Startmenu or a Desktop
shortcut with MatMaster.exe. JED enanced functions will not be available.


History
--------

Version 2.0
-----------

-Completely redesigned for a better usability.
-No separation between MAT->MTM/BMP and MTM/BMP->MAT conversion anymore.
-Preview of Cels/MipMaps possible.
-Preview of BMP/MAT files possible before opening.
-Batch Conversion
-JED Plugin integration (JED v. 0.93+ required)
-Help available.
-Associating of .MAT and .MTM files possible; Drag-from-Explorer and DDE supported.
-Fill Color for Texture MATs chooseable freely.
-the correct default CMP file (DFLT.CMP) is used now.


Version 1.01 �
--------------
Bugfixes from Version 1.0
Fixed: major bug when converting Texture MTM to MAT
Fixed: Automipping works now
Fixed: Bug with reconverting MultiMipMap MTM to MAT
Fixed: When converting a BMP, the MTM Contents list will be cleared now
Fixed: Transparency is fixed now
Fixed: Remap Palette cb behavior with Color/TX mode


Version 1�
----------
    Bugfix: bug at changing output fname after selecting textures
            has been fixed.
    Bugfix: Now Mat Master also supports Photoshop BMPs (0.8 made 4 too many
            pixels offset to the right of the data begin)

    Added: Transparent MATs supported now
    Added: Palette conversion when converting to MAT

Version 0.8�
------------
First release ever.


What this program is for:
-------------------------
You should use MatMaster as a tool to decompile/recompile Jedi Knight(tm)
material (MAT) files. Therefore it is a tool to create own textures as well
edit already available ones (don't forget about LEC's legal claims etc.!:-) )

This program is Freeware. (C) Peter Klassen, 1997-99.
The author is not responsible for any damage done by this program to your
system. You may distribute it freely via diskettes, BBS, Internet or CDs, sup-
posed that you keep the package intact and w/o modifying any files of it.
No charges must be taken for this program, except evtl. charges for the
online time.

Thanks go to:
-------------
Matthias Welander for cracking on MAT files,
Dave Lovejoy,
Alex Novikov,
Jereth Kok,
Yves Borckmans for help,
Jeff Walters and Al McDonald for Betatest,
Borland/Inprise for Delphi,
JK team for a great game.
All the people which feedback'ed MAT MASTER.

Special Thanks to
George the Mighty,

Legal stuff:

Dark Forces and Jedi Knight are (C) & (TM) LucasArts Entertainment Company.
