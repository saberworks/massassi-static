The Jedi Knight Dark Forces II Colormap Tinting Tool
by Edward

There are many tools out there to create custom colormaps (CMP) files
but none of which have ever mastered the sector tinting effect
as seen in the Capture The Flag (CTF) levels
where the team chambers are red and yellow.

This tool helps do just that, but one cannot create custom palettes with it.


How to run this?
================
This is a JAVA app, which requires Oracle's Java Runtime Environment to be
installed. Once that is done, you can either (and hopefully) double-click this
JAR and it will just run. Alternatively you open a command prompt, and run
java -jar cmptint.jar

If all goes well, the next step would be to click Load CMP and select a CMP file
you would like to modify. Once opened you will see the palette in triplicates.
The left one shows the original palette, the center one shows what it looks like
when the tint is applied, and the right one shows which color from the original
palette is the closest match to the tinted color.

Use the Red, Green and Blue sliders to get your desired tint color.
The last slider is used only to preview what it would look like
under different light levels.


Why does the third panel show the       ?
"closest matching color" to the original?
=========================================
Jedi Knight was made during the period when most computers could only handle
256 colors. There were a few with a graphics card that allowed for more.
Therefore JK was primarily made with a limited palette
but did have a 16-bit color mode as a bonus.

Each level has a common palette for the common textures found throughout the
game, but the last 64 colors in that can vary wildly depending on the theme
of the level (rusty Nar Shaddaa, greeny nature on Sulon). In the 8-bit mode
(3D Acceleration turned off) the game follows this level's only set of 256 colors.
The palette only changes when the whole screen gets tinted by damage, pickups,
force powers or the sector's tint property.
The level's lighting is handled by the CMP file.

After the main palette in the CMP file follows 64 tables of 256 indices that
point to one of the colors in the main palette that corresponds to the
darker version of that color. Say you have red at #5 and you wanted a darker red
the closest would be the next shade of red at #6.
To then tint the sector as one would see in the CTF games, that table would then
point to all shades of only red or yellow or green of the main palette.

After that table of light levels and only present in the level's main CMP
(not the ones that do the tinting like 01red or 01yellow but 01narsh)
follows 256 tables of 256 indices that point to a color that corresponds to
the mix of colors when looking through translucent surfaces.

In 16-bit mode the 8-bit textures are drawn according to the level's main palette
but the rest of the CMP is pretty much ignored. The light levels and translucency
is calculated on the fly, and the sector tinting is read from 3 decimal numbers
found in the sector's CMP's header.
