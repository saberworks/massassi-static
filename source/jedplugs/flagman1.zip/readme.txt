LEGAL DISCLAIMER
================

The Author of the acompaning program, FlagMan 1.0 is not 
responsible, liable, or accountable for any damage done to 
anyone, or anything by this program.  

This software is provided AS-IS and its use is deemed to be
acceptance of these terms.


(God I hate that I have to include this sorta thing)

Jedi_Anubis
jedi@Mosweb.com


READ FLAGMAN.TXT BEFORE USING THIS PROGRAM!!
