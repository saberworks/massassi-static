// Flagman 1.0
// Ted Thompson
// Jedi@mosweb,com
//
// Copyright 1998, All Rights Reserved

var letters = new Array();

var x, y, a, b = 0, c, d;
var Sector, Surface;

var Jed = WScript.CreateObject("JED.App"); 
var WSHShell = WScript.CreateObject("WScript.Shell");

var CurLevel = Jed.Level;
var CurSec, CurSurf;

CurSec = Jed.CurSC;
CurSurf = Jed.CurSF;

var numSectors = CurLevel.NSectors;

Sector = CurLevel.GetSector(CurSec);
Surface = Sector.GetSurface(CurSurf);

if (WSHShell.Popup("This is Flagman v1.0, it is designed to help you maintain continuity within your JK level by making the same flags appear on all surfaces using any given texture.\n\nSimply select a surface with the texture you desire (usually a floor texture), set the Surface Flags the way you want them, and run this plugin to set the Surface Flags of all surfaces using the selected texture to the selected surface's Surface Flags.", 0, "Click Ok to Continue, Cancel to Abort", 65) == 2)
   WScript.Quit();

letters[0] = "0";
letters[1] = "1";
letters[2] = "2";
letters[3] = "3";
letters[4] = "4";
letters[5] = "5";
letters[6] = "6";
letters[7] = "7";
letters[8] = "8";
letters[9] = "9";
letters[10] = "A";
letters[11] = "B";
letters[12] = "C";
letters[13] = "D";
letters[14] = "E";
letters[15] = "F";

var hexnum = "";

var SurMat = Surface.Material;

NewFlags = Surface.SurfFlags;
doit = NewFlags;
hexflag = NewFlags;

while(doit != 0)
	{
	a = hexflag / 16;
	d = Math.floor(a);
	b = 16 * d;
	c = hexflag - b
	hexnum = letters[c] + hexnum;
	hexflag = d;
	if(hexflag < 16)
		{
		hexnum = letters[hexflag] + hexnum;
		doit = 0;
		}
	}

msgstr = "WARNING: This command will set the Surface Flags of all surfaces with the \nMaterial -> " + SurMat + " <- to -> " + hexnum + " <-";

if (WSHShell.Popup(msgstr, 0, "Click Ok to Continue, Cancel to Abort", 49) == 2)
   WScript.Quit();


for (x = 0; x < numSectors; x++)
{
   Sector = CurLevel.GetSector(x);
   for (y = 0; y < Sector.NSurfaces; y++)
   {
       Surface = Sector.GetSurface(y);
       if (Surface.Material == SurMat)
       {
	  Surface.SurfFlags = NewFlags;
       }
   }
}

WSHShell.Popup("All of the matching surfaces have been flagged!", 0, "Flag Setting Completed", 65);