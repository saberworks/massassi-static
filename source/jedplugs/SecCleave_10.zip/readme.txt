Vxs Sec Cleave v1.0
By Andr� di Geronimo (adg@home.se)
copyright (c) 2004 Andr� di Geronimo



ABOUT
-----
Plugin for JED (www.codealliance.ca) that let you
cleave sectors along a plane that is defined by three 
selected vertices.



INSTALL
-------
Unzip 'SecCleave.dll' and 'SecCleave.dll.dsc' into JEDs 
plugin folder. (Re)Start JED and the plugin will be 
accessible from JEDs plugin menu.



HOW TO USE
----------
1. (Sector Mode) Multi-select the sectors you want to cleave.
2. (Vertex Mode) Multi-select three vertices (any vertices 
   found in the level). Execute the plugin.
3. The plugin will cleave all selected sectors along the plane 
   that is defined by the selected vertices.



CREDITS
-------
Thanks to Darth Slaw for the idea.
Alexei Novikov for JED.