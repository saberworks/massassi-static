var x, y;
var Sector, Surface;

var Jed = WScript.CreateObject("JED.App"); 
var WSHShell = WScript.CreateObject("WScript.Shell");
var CurLevel = Jed.Level;

var numSectors = CurLevel.NSectors;

if (WSHShell.Popup("Please pick a sky texture to flag", 0, "Flag Sky Textures", 65) == 2)
   WScript.Quit();

var SkyMat = Jed.PickMat("dflt.mat");
if (SkyMat == "") WScript.Quit();

if (WSHShell.Popup("Warning: This command will flag all surfaces with this sky texture!", 0, "Flag Sky Textures", 49) == 2)
   WScript.Quit();

for (x = 0; x < numSectors; x++)
{
   Sector = CurLevel.GetSector(x);
   for (y = 0; y < Sector.NSurfaces; y++)
   {
       Surface = Sector.GetSurface(y);
       if (Surface.Material == SkyMat)
       {
	  Surface.SurfFlags = (2<<8) + 4;
       }
   }
}

WSHShell.Popup("All of your sky textures have been flagged!", 0, "Flag Sky Textures", 65);