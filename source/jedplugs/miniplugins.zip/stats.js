var index, Sector, CurThing, Light, Cog, x, y, tpl;

//#(c) Mark Jones 1998
//#thanks to mike koger and Alexei Novikov of course!

var Jed = WScript.CreateObject("JED.App"); 
//var Thing = WScript.CreateObject("Jed.TOLEThing");

var WSHShell = WScript.CreateObject("WScript.Shell");

var CurLevel = Jed.Level;


	if (WSHShell.Popup("Are you ready to count your level stats? Larger levels may take a few minutes.", 0, "Stat Man", 65) == 2)
   WScript.Quit();

	var Surface = 0;
	
	var NumSector = CurLevel.NSectors;
	//var NumSurface = CurLevel.NSurfaces;
	var NumThing = CurLevel.Nthings;
	var NumLight = CurLevel.NLights;

	for(x=0; x < NumSector; x++) {

	Sector = CurLevel.GetSector(x);
	Surface = Surface + Sector.NSurfaces;
	}
		
WSHShell.Popup("Sectors:  " + NumSector, 0, "StatMan: Sectors", 0);
WSHShell.Popup("Surfaces:  " + Surface, 0, "StatMan: Surfaces", 0);
WSHShell.Popup("Things:  " + NumThing, 0, "StatMan: Things", 0);
WSHShell.Popup("Lights:  " + NumLight, 0, "StatMan: Lights", 0);

if (WSHShell.Popup("Would you like to find the stats for a certain template?", 0, "Stat Man", 65) == 2)
   WScript.Quit();

	tpl = Jed.PickThing("walkplayer");
	if (tpl == "") WScript.Quit();
	var TPLcount = 0;
	for(x=0; x < NumThing; x++) {	

		CurThing = CurLevel.GetThing(x);	

			if (CurThing.Template == tpl) {

			TPLcount = TPLcount + 1;
			
			}
	}

	WSHShell.Popup("There are " + TPLcount + " instances of " + tpl, 0, "StatMan: Specific Template", 0);
WScript.Quit();
					