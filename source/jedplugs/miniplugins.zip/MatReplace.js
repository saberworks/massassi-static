var Sector, Surface;
var index, sindex;
var temp;
//#(c) Mark Jones 1998
//#thanks to mike koger and Alexei Novikov of course!

var Jed = WScript.CreateObject("JED.App"); 

var WSHShell = WScript.CreateObject("WScript.Shell");

var CurLevel = Jed.Level;

var NumSector = CurLevel.NSectors;

if (WSHShell.Popup("Which MAT would you like to replace?", 0, "Mat Replace", 65) == 2)
   WScript.Quit();

var Replace = Jed.PickMat("dflt.mat");
if (Replace == "") WScript.Quit();

if (WSHShell.Popup("Replace with what MAT?", 0, "Mat Replace", 65) == 2)
   WScript.Quit();
	
	var NewMat = Jed.PickMat("dflt.mat");
	if (NewMat == "") WScript.Quit();

	if (Replace == NewMat) {

	WSHShell.Popup("The MATS are Identical!", 0, "Mat Replace", 48);
	WScript.Quit();
	}

	if (WSHShell.Popup("Are you sure that you want to replace " + Replace + " with " + NewMat + " ?", 0, "Mat Replace", 65) == 2)
   WScript.Quit();

	for (index = 0; index < NumSector; index++) {
	Sector = CurLevel.GetSector(index);
	
		temp = Sector.NSurfaces;

		for(sindex = 0; sindex < temp; sindex++) {

			Surface = Sector.GetSurface(sindex);
				if(Replace == Surface.Material) {
			//CurLevel.UpdateSector;
			Surface.Material = NewMat;
			}
		}
	}

	Jed.UpdateMap();

WSHShell.Popup("All instances of " + Replace + " have been replaced with " + NewMat , 0, "Mat Replace", 0);
					