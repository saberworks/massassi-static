var index, Sector;

//#(c) Mark Jones 1998
//#thanks to mike koger and Alexei Novikov of course!

var Jed = WScript.CreateObject("JED.App"); 

var WSHShell = WScript.CreateObject("WScript.Shell");

var CurLevel = Jed.Level;

var NumSector = CurLevel.NSectors;


	var temp = CurLevel.MasterCMP;
	if (temp == "") {

		WSHShell.Popup("No Master CMP Set!", 0, "CMP Fix", 0);
		WScript.Quit();
	}


	if (WSHShell.Popup("Warning! This will change all sector CMPs to " + temp, 0, "CMP Fix", 65) == 2)
   WScript.Quit();

	for (index = 0; index < NumSector; index++) {
	 Sector = CurLevel.GetSector(index);

		Sector.ColorMap = temp;		
	}
	
	Jed.UpdateMap();

WSHShell.Popup("Done! All sector CMPs are now " + temp, 0, "CMP Fix", 0);
WScript.Quit();
					