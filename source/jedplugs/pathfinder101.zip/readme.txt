Jed Plugin: PathFinder V1.01 By BigBosskMan
--------------------------------------------------------------------------
Description: PathFinder is a plugin which allows you to quickly create path
	     movement for Actors in Jedi Knight/Mysteries of the Sith.  For
	     example, say you have built a SP city level or something. You 
	     would most likely have civilians/aliens/whatever walking around,
	     going about their daily buisness, to enhance realism. Or if
	     your level is an Imperial base, you could have troopers on
	     patrol routes. You don't need to limit actors to simple
	     movement(point A to point B), you can create complex routes for
	     them to go on.
	     PathFinder does all the hard work for you, including creating
	     new cogs. All you gotta do is set the actors frames to where
	     you want him to move, set a few things in PathFinder, set ur
	     new cog* and you should have a fully functioning movign actor.

	     * Normally PathFinder would add the new cog for you, but due to 
	       a bug in Jed i found, I had to remove this feature, sorry :( 
	     
	     Be aware this is my first plugin, and the first version of
	     PathFinder. I plan to add more features and stuff to future
	     versions of PathFinder, so Im looking forward to suggestions :)

	     Send all bug reports/comments/suggestions to me at:
		Zone name: BigBosskMan
		Email:     b0ssk@iwc.net
		ICQ:	   26374822

Credits:     Id have to say Credits/thanks go to:
	     Code Alliance - for all them great editors
	     Sharky_TeK - for beta testing this plugin
	     And of course LucasArts, for all those awesome games!

----------------------------------------------------------------------------
Requirements:  JK/MotS, Jed .85+

Installation:  Extract the files PathFinder.exe and PathFinder.exe.dsc into
	       your Jed Plugins dir, depending on where that is. Then start
	       Jed, and choose PathFinder from the plugins menu.

~~~~~~~~~~~~~~~~~~~~~~
Usage and instructions:

	Most of the stuff in PathFinder is pretty self-explanitory, and you
	should be able to whip up new paths for actors in a minute or so,
	once you get the hang of it. A tutorial is included in this zip too.

----------------------------------------------------------------------------

Well thats it. Enjoy the plugin!

	-BigBosskMan
