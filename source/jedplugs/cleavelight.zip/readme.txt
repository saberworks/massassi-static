==JED PLUGIN====================================================
Name                    : CleaveLight 0.1b
File Name               : CleaveLight.zip
File Size               : 31kb
Author                  : Orkin Man
Date of Release         : November 2000

Email Address           : jmarst45@pipeline.westark.edu

Additional Credits to   : Alexei Novikov for JED, and LucasArts for Jedi Knight!

Beta Testers            : None yet, e-mail me if you would like to be one

Compiled With           : Microsoft Visual C++

Development machine     : K6-2 500, 64MB RAM, GeForce 256 w/32MB

==Description===================================================

Cleaves surfaces in a level so that when you use JED's lighting command
you will end up with high quality shadows (even better than lightmaps).

It will eventually use a few more techniques to improve lighting even further.

==Installation==================================================

Just extract the included DLL and DSC into your JED\plugins folder.

==How to Use it=================================================

Create your architecture, and then run the plugin. It will run through
all the surfaces effected by the light source(s) and make the necessary
cleaves automatically.

After it finishes (it could take awhile on more complex architecture),
light your level as you would normally and you should have shadows!

==Known Bugs/Problems===========================================

I haven't experienced any crashes/lockups with this plugin, but here are a few
issues that need to be worked out:

    * It's SLOW!
        It's not very feasable to use it on a real level yet. I'm still
        working on ways to speed it up.
        DO NOT USE ON VERY COMPLEX ARCHITECTURE OR IT MAY TAKE HALF AN HOUR!

    * Unnecessary cleaves
        There are two cases where it will cleave surfaces even if it doesn't
        need them to acheive the desired effect. I've figured out how to fix this,
        but haven't taken the time to code it yet. Fixing this should also improve speed.

    * You can't undo it
        There isn't any way to fix this, JED clears the undo buffer after calculating
        lighting. To get around this you must save before using the plugin, and
        then instead of using the undo command, use Revert to Saved.

==Planned Features==============================================

Here's a list of features I have planned:

    * Options Dialog
    * Progress Bar
    * Improved Speed
    * Closest Point Cleaving
    * Range Cleaving

==Miscellaneous=================================================

I hope you enjoy this plugin! I know it's not very useable yet,
but I plan on releasing some more public betas over the next few weeks
which should address the major issues.

If you have any problems/comments/suggestions feel free to e-mail
me at jmarst45@pipeline.westark.edu

==Legal Stuff====================================================

You MAY distribute this plugin, provided you include this file, with
no modifications.  You may distribute this file in any electronic
format (BBS, Diskette, CD, etc) as long as you include this file 
intact, with NO charge (other than incidental charges for time spent on-line). 
