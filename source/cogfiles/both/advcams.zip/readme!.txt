Advanced Cameras by Lord Nader

Thank you for downloading this set of cogs. You'll find these cogs extremely useful in making
single player levels and perhaps even multiplayer levels.

The flyby camera is a type of camera that focuses on a single point at a constant rate, whether 
this point is moving or standing still. For example, the part in Episode IV (Special Edition) in
which the Rebel fighters are approaching the Death Star. The camera keeps focusing on the lead 
fighter, even as it flies by.

This zip file also includes a moviecam.3do, which allows you to have cutscenes that are similar
to FMVs or most modern in-game cutscenes. For instance, if you've played any Legend of Zelda game
for the N64, whenever you use Z-targeting or are in a cutscene, those black rectangles appear at 
the bottom and top of your screen. That's what the moviecam does. So far, the only JK level I've 
seen to actually use something similar to this is "Aliens: Terror on Sigma 51-A SE". No, I did 
not use the same 3do that David McHale used in that level.

There should be 13 files included within this zip file:

03went2.mat
camera_flyby.cog
camera_flyby_corridor.cog
camera_flyby2.cog
camera_follow.cog
camera_follow_corridor.cog
cutscene.cog
demo_2.gob
demo_2readme.txt
moviecam.3do
mp_camera_flyby_corridor.cog
mp_camera_follow_corridor.cog
readme!.txt

Before you start, you need to add the template below to your level's "master" or "mots" template
file in your Project directory. (Use Wordpad or another text editor to open it.):

# DESC: 
# BBOX: -.2 -.09 -.14 .2 .12 .13
blockthing        _structure         size=.273784 movesize=.273784 model3d=moviecam.3do

After that, copy "moviecam.3do" into your project's 3do directory, and, unless you're building a
MotS level, place "03went2.mat" into your 3do/mat folder.

Note that the cogs designated with "flyby" use the moviecam 3do. Those that are designated with 
"follow" do not use the moviecam 3do.

A description of each of the cogs is below:

camera_flyby.cog: This is the basic flyby camera cog. Three values are needed for this cog. 
First, the camera itself (a ghost), a blockthing thing (use the template above), and the thing
you want the camera to continuously focus on. The blockthing must be at the same coordinates as
the ghost camera. Since the blockthing is added in outside the cog, you can make it appear or 
disappear within cutscene cogs so they do not show up in another camera angle and make the player
ask, "What's that black box over there?" Look at cutscene.cog for a better idea about what I'm 
talking about.

camera_flyby_corridor.cog: This is a specialized cog in which when the player enters one of
up to 20 sectors, the view will be switched to the flyby camera and it will continuously focus on
the "followme" thing. There are 22 values for this cog that you can fill in. The first is the 
camera thing itself (a ghost), the second is the thing you want the camera to focus on (usually 
the player), and the other 20 are the sectors in which the camera will be activated when the 
player enters that sector. There must be at least one trigger sector value entered so the cog 
will work. This cog uses the moviecam 3do.

camera_flyby2.cog: This is a variation of camera_flyby.cog. Only two values are needed for this 
cog. First, the camera itself (a ghost), and the thing you want the camera to continuously focus 
on. The blockthing template is automatically added in, unlike camera_flyby.cog, where you have to
manually add it in through JED. This cog saves you the time of having to add in the blockthing, 
but it gives you no control over the blockthing, so beware of a black object being in a cutscene
unexpectedly when it's not supposed to. If this happens, use camera_flyby.cog instead.

camera_follow.cog: This is exactly the same as camera_flyby2.cog, only that there is no moviecam 
3do used.

camera_follow_corridor.cog: Equivalent to camera_flyby_corridor.cog, except that it doesn't use
the blockthing template.

cutscene.cog: This is the master cog used to work the cutscene in the demonstration level
included. It was used in conjunction with camera_flyby.cog and camera_flyby2.cog. Check it out!

mp_camera_flyby_corridor.cog: This is a slightly altered version of camera_flyby_corridor.cog, 
modified to work with multiplayer games. *Theoretically*, it should work, but because I haven't 
tested it with someone else in multiplay, I can't guarantee that. This cog should only focus on 
the player who activated it (i.e. the local player), and there are up to 20 sectors that can 
activate the cog. The only other value you need to fill in for this cog is the camera position, 
which must be a ghost object. This cog does use the moviecam 3do.

mp_camera_follow_corridor.cog: This is the same as mp_camera_flyby_corridor.cog, but it lacks the
moviecam 3do.

The file "demo_2.gob" is a demonstration of these cogs' functions. Simply extract the gob file to
your JK episode directory, run JK, and select "Demonstration of Flyby Camera" from the SP level
list. The "demo_2readme.txt" file is simply legal stuff. Read it if you're REALLY bored.

Remember, that the best and only way to use the camera_flyby cog to its fullest is to get the
right camera angle. I believe there are some tutorials on this on massassi.net. Check it out!

If you use this cog in your levels, please give me credit, it took me a blasted month to figure
it out! :-)

If you have any questions, feel free to e-mail me at lord_nader@juno.com.