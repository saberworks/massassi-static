==============================MYSTERIES OF THE SITH BUILDER'S TOOLS==============================
Title                   : _ridler_'s Tools
File Name               : Create.ZIP
File Size               : 218 kb
Author(s)               : Josh Gomes
Download Address        : http://massassi.net
Date of Release         : 9/00

Email Address           : Mastayoda@juno.com
Misc. Author Info       : Punk rocker/ StarWars freak...
Story			: Too long to tell
Description             : Five little cogs that create cool solid objects in any level
Cog Changes		: See "The Builder's Chart.txt"

Additional Credits to   : My long-lost email buddy Bossk, who inspired me to finish this project

Beta Testers            : Me (_ridler_), Bossk, Abra_Sax

Development machine     : Pentium 400 mhz, 64 Megs of RAM, 42x CDROM
Machine(s) tested on    : Pentium 400 mhz, 64 Megs of RAM, 42x CDROM
================================================================

* Play Information *

Episode name            : N/A
Level name(s)           : N/A
JK version required     : Mysteries of the Sith Addon
Difficulty Settings     : N/A

New COGs                : YES
New Textures:
  New MATs                : NO
  New BMs                 : NO
New Objects:
  New 3DOs                : NO
  New KEYs                : NO
  New PUPs                : NO
  New AIs                 : NO
New SFTs                : NO
New WAVs                : NO
New CMPs                : NO
New PARs                : NO
New SPRs                : NO
New Briefings           : NO
New Cutscenes           : NO

* Construction *

Base                    : A few small changes in the script
Editor(s) used          : Notepad
Known Bugs              : None

================================================================

* I admit that *
(as required by the LEC Licence Agreement about Addon Levels)

1. My Level works only with the retail version of the
   Software, and does not work with any demo or OEM versions
   of the Software.  
2. My Level does not modify any COM, EXE, DLL or other executable files.
3. My Level does not contain any illegal, scandalous, 
   illicit, defamatory, libelous, or objectionable material
   (as may be determined by LEC in its sole discretion), or
   any material that infringes any trademarks, copyrights,
   protected works, publicity, proprietary, or other rights
   of any third party or of LEC.  
4. My Level does not include any LEC sound effects or music files or 
   portions thereof.
5. My Level identifies in every description file, on-
   line description, read-me, and in comments in the New
   Level code: (a) the name, address, and e-mail address of
   the level's creators, and (b) the following disclaimer:
   "THIS LEVEL IS NOT MADE, DISTRIBUTED, OR SUPPORTED BY
   LUCASARTS ENTERTAINMENT COMPANY.  ELEMENTS TM & (C) 
   LUCASARTS ENTERTAINMENT COMPANY."
6. My Level may not be sold, bartered, or distributed with
   any other product for which any charge is made (other than
   incidental charges for time spent on-line), but rather
   must be distributed free of charge. 
7. By distributing or permitting the distribution of any New
   Levels, all creators or owners of any trademark, 
   copyright, or other right, title or interest therein grant
   to LEC an irrevocable, perpetual, royalty-free, sub-
   licensable right to distribute the New Level by any means
   (whether now known or hereafter invented), and to create
   and distribute by any means (whether now known or here-
   after invented) derivative works thereof, and to charge
   for the distribution of such New Level or such derivative
   work, with no obligation to account to any creators or
   owners of the New Level in any manner.


* Copyright / Permissions *

Authors may NOT use this level as a base to build additional
levels.  
THIS LEVEL IS NOT MADE, DISTRIBUTED, OR SUPPORTED BY LUCASARTS ENTERTAINMENT 
COMPANY.  ELEMENTS TM & (C) LUCASARTS ENTERTAINMENT COMPANY.

You MAY distribute this level, provided you include this file, with
no modifications.  You may distribute this file in any electronic
format (BBS, Diskette, CD, etc) as long as you include this file 
intact, with NO charge (other than incidental charges for time spent on-line). 