COG Type: MotS Multi or Single player
COG Name: ant_lava.cog
Author: Antony Espindola
Email: ant@horrible.demon.co.uk
Web: http://www.horrible.demon.co.uk/

Description:
A number of people have requested this COG from some
unfinished work I did on a MotS SP level. This cog allows
you to create the illusion of lava, with hissing sounds
and spitting bits and smoke.

Simply define 5 things on your lava surface, placed
randomly about, and assign these to the 5 things
in the cog. Use the lava.wav for the sound and experiment
with the timings to your liking. You can always use
this cog more than once for a larger area.

Please give credit if you use this cog, by mentioning
my name and my website, as above.

And yes, I may release the unfinished level if I get
enough nagging emails!

Enjoy!