==JEDI KNIGHT ADDON=============================================
Title                   : Jk Rain
File Name               : jkrain.zip
File Size               : 16.6kb (UnZipped) 
Author(s)               : EL3CTRO and an idea by Oberfeldwebel
Date of Release         : November 2001

Email Address           : electro@stargatecommand.co.uk
Misc. Author Info       : :)

Description             : This will generate rain in levels.  See INSTALLATION.TXT for more info.

Additional Credits to   : Oberfeldwebel (Original Consept), Lordvader (Cog help [i probably annoyed the hell outta him with all my questions :D]), The_New_Guy (More cog help), GBK (Even more cog help), ~Rishka~ (Guess what? COG HELP!)

Beta Testers            : Brian, oSiRiS, Oberfeldwebel, SDA_Lakusi

Development machine     : AMD K-62 333Mhz with 112MB RAM, Riva TNT 16MB PCI
Machine(s) tested on    : 400Mhz Celeron, 233Mhz Pentium, Others unknown.
================================================================

* Play Information *

New COGs                : Yes
New Textures:
  New MATs              : Yes
  New BMs               : No
New Objects:
  New 3DOs              : No
  New KEYs              : No
  New PUPs              : No
  New AIs               : No
New SFTs                : No
New WAVs                : No
New CMPs                : No
New PARs                : No
New SPRs                : Yes
New Briefings           : No
New Cutscenes           : No
New Template Entries	: Yes

* Construction *

Base                    : New cog from scratch.
Editor(s) used          : Jed Beta .95, CogED
Known Bugs              : If you make too many ghost objects, it will stop the weapons from firing.

================================================================

* I admit that * 
(as required by the LEC Licence Agreement about Addon Levels)

1. My Level works only with the retail version of the
   Software, and does not work with any demo or OEM versions
   of the Software.  
2. My Level does not modify any COM, EXE, DLL or other executable files.
3. My Level does not contain any illegal, scandalous, 
   illicit, defamatory, libelous, or objectionable material
   (as may be determined by LEC in its sole discretion), or
   any material that infringes any trademarks, copyrights,
   protected works, publicity, proprietary, or other rights
   of any third party or of LEC.  
4. My Level does not include any LEC sound effects or music files or 
   portions thereof.
5. My Level identifies in every description file, on-
   line description, read-me, and in comments in the New
   Level code: (a) the name, address, and e-mail address of
   the level's creators, and (b) the following disclaimer:
   "THIS LEVEL IS NOT MADE, DISTRIBUTED, OR SUPPORTED BY
   LUCASARTS ENTERTAINMENT COMPANY.  ELEMENTS TM & (C) 
   LUCASARTS ENTERTAINMENT COMPANY."
6. My Level may not be sold, bartered, or distributed with
   any other product for which any charge is made (other than
   incidental charges for time spent on-line), but rather
   must be distributed free of charge. 
7. By distributing or permitting the distribution of any New
   Levels, all creators or owners of any trademark, 
   copyright, or other right, title or interest therein grant
   to LEC an irrevocable, perpetual, royalty-free, sub-
   licensable right to distribute the New Level by any means
   (whether now known or hereafter invented), and to create
   and distribute by any means (whether now known or here-
   after invented) derivative works thereof, and to charge
   for the distribution of such New Level or such derivative
   work, with no obligation to account to any creators or
   owners of the New Level in any manner.

* Copyright / Permissions *

Authors may use this cog as a base to build additional cog or improove on this one as long as you e-mail me (electro@stargatecommand.co.uk) or contact me at massassi or whatever, just let me know.  
THIS LEVEL IS NOT MADE, DISTRIBUTED, OR SUPPORTED BY LUCASARTS ENTERTAINMENT 
COMPANY.  ELEMENTS TM & (C) LUCASARTS ENTERTAINMENT COMPANY.



You MAY distribute this level, provided you include this file, with
no modifications.  You may distribute this file in any electronic
format (BBS, Diskette, CD, etc) as long as you include this file 
intact, with NO charge (other than incidental charges for time spent on-line). 


