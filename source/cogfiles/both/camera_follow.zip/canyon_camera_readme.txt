==JEDI KNIGHT ADDON MISSION====================================
Title                   : Canyon_Camera
File Name               : camera_follow.ZIP
File Size               : 178 KB
Author(s)               : Lord Nader
Date of Release         : 2/02
Email Address           : lord_nader@juno.com
Misc. Author Info       : I'm unbeatable at SBX, heheh, watch out for me on the Zone when JK2 
			comes out! Zone name LordNader85
Description             : Demonstration of camera_follow cog. I don't know if it would work in
			actual multiplay
Beta Testers            : Me
Development machine     : Win98 w/ 4 meg graphics card (yuck!)
Machine(s) tested on    : See above
================================================================

* Play Information *

Episode name            : Canyon Oasis - Camera Follow
Level name(s)           : Canyon Oasis - Camera_Follow
JK version required     : Jedi Knight Basic
Difficulty Settings     : Nope

New COGs                : Yeah!
New Textures:
  New MATs              : Nope
  New BMs               : Nope
New Objects:
  New 3DOs              : Nope
  New KEYs              : Nope
  New PUPs              : Nope
  New AIs               : Nope
New SFTs                : Nope
New WAVs                : Nope
New CMPs                : Nope
New PARs                : Nope
New SPRs                : Nope
New Briefings           : Nope
New Cutscenes           : Not exactly . . .

* Construction *

Base                    : Canyon Oasis
Editor(s) used          : JED v.95
Known Bugs              : No bugs that'll crash your computer or cause you to groan in 
			frustration. Check readme!.txt for so-called "bugs".

================================================================

* I admit that * 
(as required by the LEC Licence Agreement about Addon Levels)

1. My Level works only with the retail version of the
   Software, and does not work with any demo or OEM versions
   of the Software.  
2. My Level does not modify any COM, EXE, DLL or other executable files.
3. My Level does not contain any illegal, scandalous, 
   illicit, defamatory, libelous, or objectionable material
   (as may be determined by LEC in its sole discretion), or
   any material that infringes any trademarks, copyrights,
   protected works, publicity, proprietary, or other rights
   of any third party or of LEC.  
4. My Level does not include any LEC sound effects or music files or 
   portions thereof.
5. My Level identifies in every description file, on-
   line description, read-me, and in comments in the New
   Level code: (a) the name, address, and e-mail address of
   the level's creators, and (b) the following disclaimer:
   "THIS LEVEL IS NOT MADE, DISTRIBUTED, OR SUPPORTED BY
   LUCASARTS ENTERTAINMENT COMPANY.  ELEMENTS TM & (C) 
   LUCASARTS ENTERTAINMENT COMPANY."
6. My Level may not be sold, bartered, or distributed with
   any other product for which any charge is made (other than
   incidental charges for time spent on-line), but rather
   must be distributed free of charge. 
7. By distributing or permitting the distribution of any New
   Levels, all creators or owners of any trademark, 
   copyright, or other right, title or interest therein grant
   to LEC an irrevocable, perpetual, royalty-free, sub-
   licensable right to distribute the New Level by any means
   (whether now known or hereafter invented), and to create
   and distribute by any means (whether now known or here-
   after invented) derivative works thereof, and to charge
   for the distribution of such New Level or such derivative
   work, with no obligation to account to any creators or
   owners of the New Level in any manner.

* Copyright / Permissions *

Authors (MAY/may NOT) use this level as a base to build additional levels.  
THIS LEVEL IS NOT MADE, DISTRIBUTED, OR SUPPORTED BY LUCASARTS ENTERTAINMENT 
COMPANY.  ELEMENTS TM & (C) LUCASARTS ENTERTAINMENT COMPANY.

(One of the following)

You MAY distribute this level, provided you include this file, with
no modifications.  You may distribute this file in any electronic
format (BBS, Diskette, CD, etc) as long as you include this file 
intact, with NO charge (other than incidental charges for time spent on-line). 