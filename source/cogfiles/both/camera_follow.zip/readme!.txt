Camera_Follow Cog by Lord Nader

Thank you for downloading this set of cogs. You'll find these cogs extremely useful in making
single player and perhaps even implementing them in multiplayer levels.

The "follow" camera, better known as the flyby camera, is a type of camera that focuses on a
single point at a constant rate, whether this point is moving or standing still. For example, the
part in Episode IV (Special Edition) in which the Rebel fighters are approaching the Death Star.
The camera keeps focusing on the lead fighter, even as it flies by.

There should be six files included within this zip file:

camera_follow.cog
camera_follow_corridor.cog
canyon_camera.gob
canyon_camera_readme.txt
mp_camera_follow_corridor.cog
readme!.txt

Before you start, you need to add this template to your level's "master" or "mots" template file.
(Use Wordpad or another text editor to open it.):

# DESC: 
# BBOX: -.01 -.01 -.01 .01 .01 .01
remotecamera      greedo  size=.01477 movesize=.01477 model3d=remo.3do physflags=0x2006a06 collide=0 soundclass=re.snd

A description of each of the cogs is below:

camera_follow.cog: This is the basic flyby camera cog. Only two values are need for this cog. 
First, the camera itself (use the template above for the thing), and secondly, the thing you want
the camera to continously focus on.

camera_follow_corridor.cog: This is a specialized cog in which when the player enters one of
up to 20 sectors, the view will be switched to the flyby camera and it will continously focus on
the "followme" thing. There are 22 values for this cog that you can fill in. The first is the 
camera thing itself (use the template above), the second is the thing you want the camera to 
focus on (usually the player), and the other 20 are the sectors in which the camera will be 
activated when the player enters that sector. There must be at least one trigger sector value
entered so the cog will work.

mp_camera_follow_corridor.cog: This is a slightly altered version of camera_follow_corridor.cog.
*Theoretically*, it should work, but because I haven't tested it with someone else in multiplay,
I can't guarantee that. This cog should only focus on the player who activated it, and there are
up to 20 sectors that can activate the cog. The only other value you need to fill in for this cog
is the camera position, which must be a ghost object, and *NOT* a remotecamera thing. You still
need to add the remotecamera template to your level, though.

*BUGS!* Keep in mind that while this cog can be placed at any position in a level (it hovers in
place, basically), it can't move. I don't know why, but the camera refuses to move. In addition,
unless in a cutscene, the player can switch from the follow_camera's point of view to 3rd person
by hitting the F1 key. (Similar to MotS cutscenes.) If you have an idea on how to fix these
problems, please e-mail me at lord_nader@juno.com. However, you do not have to worry about the
camera being destroyed in any way, even if it's underwater. In addition, the game will not crash
if the followme thing is killed.

The file "canyon_camera.gob" is a demonstration of this cog's function. (Basically it's Canyon
Oasis with the cogs added.) Simply stick this file in your JK episode directory, run JK, and 
select it from the multiplayer level list. Even if you don't use the follow_camera, you can use
this modification of CO to test patches and/or get a better look at new MP skins.

Remember, that the best and only way to use the camera_follow cog to its fullest is to get the
right camera angle. I believe there are some tutorials on this on massassi.net. Check it out!

If you have any questions, feel free to e-mail me at lord_nader@juno.com.