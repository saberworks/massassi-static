MP Self Destruct Cog
== ==== ======== ===
By Brendan Smithyman
Aka Flaming Monkey Trooper


This cog starts a timer, plays various sounds, and kills all players/actors in 10 sectors after activated by a surface.

Property		|	Description
=================================================
button (surface)	|	switch surface
-------------------------------------------------
triggerID (int)		|	trigger ID called
			|	to synch with
			|	special fx cogs
-------------------------------------------------
sector0 - sector9	|	sectors affected
			|	by blast
-------------------------------------------------
click			|	switch sound
-------------------------------------------------
alarm			|	minor alarm between
			|	voice parts
-------------------------------------------------
explosion		|	reactor explosion
			|	sound
=================================================

A trigger can be set that will be called at explosion, to synch the deaths with any external cogs for explosions, special fx, etc.  Trigger calls with all four paramaters set to 0, only a simple trigger with no parameters.

Included is an expansion cog that allows the self destruct to affect everyone in the level, instead of certain areas.
Simply include it in your level, and set the triggerID paramater to the same as the self destruct cog.