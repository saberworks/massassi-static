==JEDI KNIGHT ADDON MISSION====================================
Title                   :
File Name               : showdowncogs.ZIP
File Size               : 25 kb
Author(s)               : Maheda, Arby, Hideki
Date of Release         : October 2000
Email Address           : Maheda: Maheda@ignmail.com
			  Arby: 
			  Hideki: 
Misc. Author Info       : 
Description             : See "Cog Info.txt" 
Additional Credits to   : The staff of the original Showdown
Beta Testers            : The staff of the original Showdown
Development machine     : Various
Machine(s) tested on    : Various
================================================================ 
* Play Information * 
Cog group name         	: Original Showdown Cogs
Cog name(s)           	: fight_main.cog, fightcam.cog, force_well.cog, item_shieldbelt.cog
			  items.dat, jkstrings.uni, special1.cog, weap_fists.cog
JK version required     : Jedi Knight Basic
Difficulty Settings     : Not implemented 
New COGs                : That's what this is.
New Textures:
  New MATs              : No
  New BMs               : No
New Objects:
  New 3DOs              : No
  New KEYs              : No
  New PUPs              : No
  New AIs               : No
New SFTs                : No
New WAVs                : No
New CMPs                : No
New PARs                : No
New SPRs                : No
New Briefings           : No
New Cutscenes           : No 
* Construction * 
Base                    : Various new cogs from scratch, modified LEC cogs
Editor(s) used          : Cogwriter, COGED, Notepad
Known Bugs              : Need various user inputed components to work 
================================================================ 
* I admit that *
(as required by the LEC Licence Agreement about Addon Levels)
1. My Level works only with the retail version of the
   Software, and does not work with any demo or OEM versions
   of the Software. 
2. My Level does not modify any COM, EXE, DLL or other executable files.
3. My Level does not contain any illegal, scandalous,
   illicit, defamatory, libelous, or objectionable material
   (as may be determined by LEC in its sole discretion), or
   any material that infringes any trademarks, copyrights,
   protected works, publicity, proprietary, or other rights
   of any third party or of LEC. 
4. My Level does not include any LEC sound effects or music files or
   portions thereof.
5. My Level identifies in every description file, on-
   line description, read-me, and in comments in the New
   Level code: (a) the name, address, and e-mail address of
   the level's creators, and (b) the following disclaimer:
   "THIS LEVEL IS NOT MADE, DISTRIBUTED, OR SUPPORTED BY
   LUCASARTS ENTERTAINMENT COMPANY.  ELEMENTS TM & (C)
   LUCASARTS ENTERTAINMENT COMPANY."
6. My Level may not be sold, bartered, or distributed with
   any other product for which any charge is made (other than
   incidental charges for time spent on-line), but rather
   must be distributed free of charge.
7. By distributing or permitting the distribution of any New
   Levels, all creators or owners of any trademark,
   copyright, or other right, title or interest therein grant
   to LEC an irrevocable, perpetual, royalty-free, sub-
   licensable right to distribute the New Level by any means
   (whether now known or hereafter invented), and to create
   and distribute by any means (whether now known or here-
   after invented) derivative works thereof, and to charge
   for the distribution of such New Level or such derivative
   work, with no obligation to account to any creators or
   owners of the New Level in any manner.
* Copyright / Permissions *
Authors may use these cogs as a base to build additional cogs.  They may also use them in Showdown-esque levels.
Proper credit MUST be given.
THIS LEVEL IS NOT MADE, DISTRIBUTED, OR SUPPORTED BY LUCASARTS ENTERTAINMENT
COMPANY.  ELEMENTS TM & (C) LUCASARTS ENTERTAINMENT COMPANY. 
(One of the following) You MAY distribute this level, provided you include this file, with
no modifications.  You may distribute this file in any electronic
format (BBS, Diskette, CD, etc) as long as you include this file
intact, with NO charge (other than incidental charges for time spent on-line).